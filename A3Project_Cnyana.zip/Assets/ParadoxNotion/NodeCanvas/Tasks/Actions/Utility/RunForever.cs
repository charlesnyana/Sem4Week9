﻿using NodeCanvas.Framework;
using ParadoxNotion.Design;


namespace NodeCanvas.Tasks.Actions
{

    //Simple as that :P
    [Category("✫ Utility")]
    [Description("An action that will simply run forever and never finish")]
    public class RunForever : ActionTask
    {

    }
}